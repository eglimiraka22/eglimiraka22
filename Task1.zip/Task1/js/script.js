var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var author = document.getElementsByClassName("author");

  var dots = document.getElementsByClassName("dot");
  var dot1=document.getElementsByClassName("dot").innerHtml;
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
      author[i].style.display = "none";  


  }
  
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
     

  }
  slides[slideIndex-1].style.display = "block"; 
  author[slideIndex-1].style.display = "inline";  

  dots[slideIndex-1].className += " active";
  dots[slideIndex-1].style.backgroundColor='white'
  dots[slideIndex+1].style.backgroundColor='black'
  dots[slideIndex].style.backgroundColor='black'






            }


        


window.onload= function () {
  setInterval(function(){ 
     plusSlides(1);
  }, 3000);
 }


 document.addEventListener("DOMContentLoaded", function(){

    el_autohide = document.querySelector('.autohide');
    
    // add padding-top to body (if necessary)
    navbar_height = document.querySelector('.navbar').offsetHeight;
  
    if(el_autohide){
      var last_scroll_top = 0;
      window.addEventListener('scroll', function() {
            let scroll_top = window.scrollY;
           if(scroll_top < last_scroll_top) {
                el_autohide.classList.remove('scrolled-down');
                el_autohide.classList.add('scrolled-up');
                
            }
            else {
                el_autohide.classList.remove('scrolled-up');
                el_autohide.classList.add('scrolled-down');
            }
            last_scroll_top = scroll_top;
      }); 
      // window.addEventListener
    }
    // if
  
  }); 